package com.swastik.model;

/**
 *
 * @author Sohan_Maali
 */
public class UpdationRequestDto {

}
